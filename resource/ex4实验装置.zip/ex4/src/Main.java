import java.io.*;

/**
 * The main function of the oberon compiler
 * 
 */
public class Main
{
	/**
	 * The test of the Oberon compiler
	 * @param argv parameter of the cmd
	 * @throws FileNotFoundException 
	 */
	public static void main(String argv[])throws Exception
	{
		//deal with the circumstances
		if (argv.length == 0){
			//no input file
			System.out.println("You should input some test files.");
		}
		else{
			//for all the test
			for (int i = 0; i < argv.length; i++) 
			{
				//get the instance of the lexer
				OberonScanner obj = new OberonScanner(new java.io.FileReader(argv[i]));
				//start the parse
				OberonParser p=new OberonParser(obj);
				System.out.println(argv[i] + ":");
				try{	
					p.parse();
				}
				catch(Exception ex){
					System.out.println("error occurs at : "+(obj.get_line()+1)+" line "+(obj.get_column()+1)+" column");
					System.out.println(ex.getMessage());
					System.out.println(obj.yytext());
				}
				System.out.println();
			}
		}
	}
}

