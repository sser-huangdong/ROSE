package exceptions;

// Referenced classes of package exceptions:
//            SyntacticException

public class MissingSeparatorException extends SyntacticException
{

    public MissingSeparatorException()
    {
        this("The separator is missing");
    }

    public MissingSeparatorException(String s)
    {
        super(s);
    }
}