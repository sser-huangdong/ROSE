package exceptions;

// Referenced classes of package exceptions:
//            SyntacticException

public class ModuleNameMismatchedException extends SyntacticException
{

    public ModuleNameMismatchedException()
    {
        this("Module Name Mismatched Exception.");
    }

    public ModuleNameMismatchedException(String s)
    {
        super( s);
    }
}