package exceptions;

// Referenced classes of package exceptions:
//            SyntacticException

public class IllegalArrayLengthException extends SyntacticException
{

    public IllegalArrayLengthException()
    {
        this("Length of array is illegal.");
    }

    public IllegalArrayLengthException(String s)
    {
        super( s);
    }
}