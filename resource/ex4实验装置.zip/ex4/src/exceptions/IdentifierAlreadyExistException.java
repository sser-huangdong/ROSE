package exceptions;

// Referenced classes of package exceptions:
//            SemanticException

public class IdentifierAlreadyExistException extends SemanticException
{

    public IdentifierAlreadyExistException()
    {
        this("The identifier is already exists.");
    }

    public IdentifierAlreadyExistException(String s)
    {
        super( s);
    }
}