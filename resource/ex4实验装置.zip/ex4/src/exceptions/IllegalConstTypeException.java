package exceptions;

// Referenced classes of package exceptions:
//            SyntacticException

public class IllegalConstTypeException extends SyntacticException
{

    public IllegalConstTypeException()
    {
        this("Type of const is illegal.");
    }

    public IllegalConstTypeException(String s)
    {
        super( s);
    }
}